using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Rubidium2018.Controllers.Notify;
using Rubidium2018.Database;
using SixLabors.ImageSharp.Web;
using System.Text;

var builder = WebApplication.CreateBuilder(args);


// db
builder.Services.AddDbContextFactory<RecDBContext>(
	options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"), sql => { sql.EnableRetryOnFailure(3); })
	);

// auth
var key = Encoding.ASCII.GetBytes(DBConfig.JwtKey);
builder.Services.AddAuthentication(options =>
{
	options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
	options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
	options.RequireHttpsMetadata = false;
	options.SaveToken = true;
	options.TokenValidationParameters = new TokenValidationParameters
	{
		ValidateIssuerSigningKey = true,
		IssuerSigningKey = new SymmetricSecurityKey(key),
		ValidateIssuer = false,
		ValidateAudience = false,
	};
});
// api
builder.Services.AddImageSharp(options =>
{
	options.OnParseCommandsAsync = context =>
	{
		var commands = context.Commands;

		if (commands.TryGetValue("cropSquare", out var cropValue) &&
			cropValue == "1" &&
			commands.TryGetValue("width", out var widthValue) &&
			int.TryParse(widthValue, out int width))
		{
			commands["height"] = width.ToString();
			commands["rmode"] = "crop";
		}

		return Task.CompletedTask;
	};
});
builder.Services.AddControllers().AddJsonOptions(options =>
{
	options.JsonSerializerOptions.PropertyNamingPolicy = null;
	options.JsonSerializerOptions.WriteIndented = true;
});
builder.Services.AddSignalR();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddHttpClient();

var app = builder.Build();

Notify.DbFactory = app.Services.GetRequiredService<IDbContextFactory<RecDBContext>>();
RecDB.DbFactory = app.Services.GetRequiredService<IDbContextFactory<RecDBContext>>();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapHub<NotifyHub>("/notify/hub/v1");

app.Run();