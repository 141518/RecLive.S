﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Rubidium2018.RecNet.Platforms.Enums;

namespace Rubidium2018.Rubidium.Auth.CachedLogins;

public class RbCachedLogin
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long CachedLoginId { get; set; }
    
    public PlatformType Platform { get; set; }
    public string PlatformId { get; set; }
    
    public long PlayerId { get; set; }
}