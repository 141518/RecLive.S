﻿using Rubidium2018.RecNet.Platforms;
using Rubidium2018.RecNet.Players;
using Rubidium2018.Utils;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using Rubidium2018.RecNet.Generic;
using Rubidium2018.RecNet.Players.Avatars;
using Rubidium2018.RecNet.Players.Presence;

namespace Rubidium2018.Rubidium.Players
{
	public class RBPlayer
	{
		[Key]
		public long Id { get; set; }

		public string Username { get; set; } = string.Empty;
		public string DisplayName { get; set; } = string.Empty;
		public string ProfileImageName { get; set; } = "default";
		public string Bio { get; set; } = string.Empty;

		public int XP { get; set; } = 0;
		public int Level { get; set; } = 1;

		public bool JuniorProfile { get; set; } = false;
		public bool ForceJuniorImages { get; set; } = false;
		public bool PendingJunior { get; set; } = false;
		public bool HasBirthday { get; set; } = false;

		[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
		public bool? AvoidJuniors { get; set; }

		public bool CanReceiveInvites { get; set; } = false;

		public bool Developer { get; set; } = false;

		// update these after adding to DB
		public string Presence { get; set; } = new PlayerPresence().ToJson();
		public string PlayerReputation { get; set; } = new Reputation().ToJson();
		public string PlatformId { get; set; } = new PlatformMapping().ToJson();

		public string Avatar { get; set; } = RBDefaults.DefaultAvatar;
		public string Outfits { get; set; } = "[]";
		
		public string Settings { get; set; } = RBDefaults.DefaultSettings;

		public PlayerPresence GetPresence()
		{
			return Presence.FromJson<PlayerPresence>();
		}
		public Reputation GetReputation()
		{
			return PlayerReputation.FromJson<Reputation>();
		}
		public Avatar GetAvatar()
		{
			return Avatar.FromJson<Avatar>();
		}
		public List<SavedOutfit> GetSavedOutfits()
		{
			return Outfits.FromJson<List<SavedOutfit>>();
		}
		public List<KeyValue> GetPlayerSettings()
		{
			return Settings.FromJson<List<KeyValue>>();
		}
		
		public static RBPlayer Create(string username, PlatformMapping platform)
		{
			var newPlayer = new RBPlayer();
			newPlayer.Username = username;
			newPlayer.DisplayName = username;
			newPlayer.PlayerReputation = new Reputation().ToJson();
			newPlayer.PlatformId = platform.ToJson();
			return newPlayer;
		}
	}
}
