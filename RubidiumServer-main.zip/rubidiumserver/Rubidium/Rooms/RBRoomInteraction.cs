﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Rubidium2018.Rubidium.Rooms;

public class RBRoomInteraction
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long InteractionId { get; set; }
    
    public long RoomId { get; set; }
    public long AccountId  { get; set; }

    public bool Visited { get; set; } = false;
    public DateTime? VisitedAt { get; set; } = null;
    
    public bool Cheered { get; set; }
    public DateTime? CheeredAt { get; set; } = null;
    
    public bool Favorited { get; set; }
    public DateTime? FavoritedAt { get; set; } = null;
}