﻿using Microsoft.EntityFrameworkCore;
using Rubidium2018.RecNet.Rooms;

namespace Rubidium2018.Rubidium.Rooms;

public class RBRoom : Room
{
    public string CoOwnerIds { get; set; } = "[]";
    public string InvitedCoOwnerIds { get; set; } = "[]";
    
    public string HostIds { get; set; } = "[]";
    public string InvitedHostIds { get; set; } = "[]";
}