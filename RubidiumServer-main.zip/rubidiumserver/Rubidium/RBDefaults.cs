﻿using Rubidium2018.RecNet.RecRoom.Config;

namespace Rubidium2018.Rubidium
{
	public static class RBDefaults
	{
		// temporary!!
		public const string DefaultAvatar = "{\"OutfitSelections\":\"d0a9262f-5504-46a7-bb10-7507503db58e,95e4cc30-cb68-473d-a395-feadf5b51512,,,1\",\"FaceFeatures\":\"{\\\"ver\\\":3,\\\"eyeId\\\":\\\"AjGMoJhEcEehacRZjUMuDg\\\",\\\"eyePos\\\":{\\\"x\\\":0.0,\\\"y\\\":0.0},\\\"eyeScl\\\":0.0,\\\"mouthId\\\":\\\"FrZBRanXEEK29yKJ4jiMjg\\\",\\\"mouthPos\\\":{\\\"x\\\":0.0,\\\"y\\\":0.0},\\\"mouthScl\\\":0.0,\\\"beardColorId\\\":\\\"befcc00a-a2e6-48e4-864c-593d57bbbb5b\\\"}\",\"SkinColor\":\"85343b16-d58a-4091-96d8-083a81fb03ae\",\"HairColor\":\"fT0t-J1A-0i_tdoogFEz-g\"}";
		public const string DefaultSettings = "[{\"Key\":\"MOD_BLOCKED_TIME\",\"Value\":\"0\"},{\"Key\":\"MOD_BLOCKED_DURATION\",\"Value\":\"0\"},{\"Key\":\"PlayerSessionCount\",\"Value\":\"1\"},{\"Key\":\"ShowRoomCenter\",\"Value\":\"1\"},{\"Key\":\"QualitySettings\",\"Value\":\"3\"},{\"Key\":\"Recroom.OOBE\",\"Value\":\"100\"},{\"Key\":\"VoiceFilter\",\"Value\":\"0\"},{\"Key\":\"VIGNETTED_TELEPORT_ENABLED\",\"Value\":\"1\"},{\"Key\":\"CONTINUOUS_ROTATION_MODE\",\"Value\":\"1\"},{\"Key\":\"ROTATION_INCREMENT\",\"Value\":\"0\"},{\"Key\":\"ROTATE_IN_PLACE_ENABLED\",\"Value\":\"0\"},{\"Key\":\"TeleportBuffer\",\"Value\":\"0\"},{\"Key\":\"VoiceChat\",\"Value\":\"0\"},{\"Key\":\"PersonalBubble\",\"Value\":\"0\"},{\"Key\":\"ShowNames\",\"Value\":\"1\"},{\"Key\":\"H.264 plugin\",\"Value\":\"0\"},{\"Key\":\"google_analytics_clientid_pref_key\",\"Value\":\"YPSBPEGEf8ed48c71d2e0ddd40bebb2d09d0dc1ac53377ca\"},{\"Key\":\"USER_TRACKING\",\"Value\":\"53\"},{\"Key\":\"IgnoreBuffer\",\"Value\":\"0\"},{\"Key\":\"FIRST_TIME_IN_FLAGS\",\"Value\":\"0\"},{\"Key\":\"WALKING_MODE\",\"Value\":\"1\"},{\"Key\":\"COMFORT_FLY\",\"Value\":\"0\"},{\"Key\":\"COMFORT_SMOOTH_ROTATE\",\"Value\":\"0\"},{\"Key\":\"COMFORT_SWIPE_ROTATE\",\"Value\":\"0\"},{\"Key\":\"COMFORT_TELEPORT\",\"Value\":\"0\"},{\"Key\":\"COMFORT_WALK\",\"Value\":\"0\"},{\"Key\":\"COMFORT_SPRINT\",\"Value\":\"0\"},{\"Key\":\"COMFORT_VEHICLES\",\"Value\":\"0\"},{\"Key\":\"DAILY_LOGIN_DATE\",\"Value\":\"2\"},{\"Key\":\"OBJECTIVE_DATE\",\"Value\":\"2\"},{\"Key\":\"OBJECTIVE_PROGRESS0\",\"Value\":\"0\"},{\"Key\":\"OBJECTIVE_COMPLETED0\",\"Value\":\"0\"},{\"Key\":\"OBJECTIVE_PROGRESS1\",\"Value\":\"0\"},{\"Key\":\"OBJECTIVE_COMPLETED1\",\"Value\":\"0\"},{\"Key\":\"OBJECTIVE_PROGRESS2\",\"Value\":\"0\"},{\"Key\":\"OBJECTIVE_COMPLETED2\",\"Value\":\"0\"},{\"Key\":\"SFX_VOLUME_PERCENT_PREF\",\"Value\":\"0.8265823\"},{\"Key\":\"SCREENS_INVERT_MOUSE\",\"Value\":\"0\"},{\"Key\":\"SCREENS_MOUSE_SENSITIVITY_X\",\"Value\":\"1.187885\"},{\"Key\":\"SCREENS_MOUSE_SENSITIVITY_Y\",\"Value\":\"1.100286\"},{\"Key\":\"MOTION_TELEPORT_ENABLED\",\"Value\":\"0\"},{\"Key\":\"BACKPACK_FAVORITE_TOOL\",\"Value\":\"-1\"},{\"Key\":\"SplitTestAssignedSegments\",\"Value\":\"1|{\\\"SplitTesting+NUX_HoloHelpers_2019_11_15\\\":\\\"On\\\"}\"},{\"Key\":\"SCREENS_HEAD_BOB\",\"Value\":\"0\"},{\"Key\":\"MUSIC_VOLUME_PERCENT_PREF\",\"Value\":\"1\"},{\"Key\":\"SCREENS_CAMERA_RELATIVE_DANCE_CONTROLS\",\"Value\":\"0\"},{\"Key\":\"AMBIENCE_VOLUME_PERCENT_PREF\",\"Value\":\"1\"}]";
		
		public static void Set()
		{
			RecRoomConfig.Active = new RecRoomConfig();
			RecRoomConfig.TryRefreshDaily();
		}
	}
}
