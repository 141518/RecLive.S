﻿using Rubidium2018.RecNet.Players.Progression;
using Rubidium2018.RecNet.Players.Progression.Enums;

namespace Rubidium2018.Rubidium.Progression
{
	public class RBPresetDailys : RBObjective
	{
		private static ObjectiveType[] DisallowedTypes = {
			ObjectiveType.AllDailyObjectives,
			ObjectiveType.FirstSessionOfDay,
			ObjectiveType.AllOtherChallenges,
			ObjectiveType.NUX_AllPunchcardObjectives,
			ObjectiveType.NUX_PunchcardObjective,
			ObjectiveType.DailyObjective3,
			ObjectiveType.DailyObjective2,
			ObjectiveType.DailyObjective1,
			ObjectiveType.OOBE_GoToActivity,
			ObjectiveType.OOBE_GoToLockerRoom,
			ObjectiveType.OOBE_FinishActivity
		};

		private static ObjectiveType[] AllowedTypes()
		{
			var allowed = Enum.GetValues(typeof(ObjectiveType)).Cast<ObjectiveType>().Where(o => !DisallowedTypes.Contains(o)).ToArray();
			return allowed;
		}

		public static ObjectiveType GetRandomObjectiveType()
		{
			var allowed = AllowedTypes();
			return allowed[Random.Shared.Next(allowed.Length)];
		}

		public static Objective CreateRandomObjective()
		{
			var objectiveType = GetRandomObjectiveType();
			return new Objective
			{
				ObjectiveType = objectiveType,
				RequiredScore = ((int)objectiveType >= 100) ? 3 : 1
			};
		}
	}
}
