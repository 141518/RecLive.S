﻿using Rubidium2018.RecNet.Players.Progression.Enums;
using Rubidium2018.RecNet.Players.Progression;

namespace Rubidium2018.Rubidium.Progression
{
	public interface RBObjective
	{
		private static ObjectiveType[] DisallowedTypes;

		private static ObjectiveType[] AllowedTypes() { return []; }
		public static ObjectiveType GetRandomObjectiveType() { return ObjectiveType.Default; }
		public static Objective CreateRandomObjective() { return null; }
	}
}
