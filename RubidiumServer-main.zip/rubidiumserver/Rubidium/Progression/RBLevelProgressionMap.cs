﻿namespace Rubidium2018.Rubidium.Progression
{
	public class RBLevelProgressionMap
	{
		private const int MaxLevel = 30;

		private static Dictionary<int, int> Cached;

		public static Dictionary<int, int> Get()
		{
			if (Cached != null) return Cached;

			var tiers = new[]
			{
				new { Start = 1,  End = 3,  Xp = 10 },
				new { Start = 4,  End = 10, Xp = 20 },
				new { Start = 11, End = 20, Xp = 45 },
				new { Start = 21, End = 30, Xp = 115 }
			};

			Cached = new Dictionary<int, int>();

			foreach (var tier in tiers)
			{
				for (int level = tier.Start; level <= tier.End; level++)
				{
					Cached[level] = tier.Xp;
				}
			}

			return Cached;
		}
	}
}
