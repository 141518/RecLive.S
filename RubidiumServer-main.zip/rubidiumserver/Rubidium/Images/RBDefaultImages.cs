﻿namespace Rubidium2018.Rubidium.Images;

public static class RBDefaultImages
{
    public const string DefaultRoomImage = "DefaultRoomImage.jpg";
}