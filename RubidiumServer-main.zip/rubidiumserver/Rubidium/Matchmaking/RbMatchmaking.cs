﻿namespace Rubidium2018.Rubidium.Matchmaking;

public class RbMatchmaking
{
    
}