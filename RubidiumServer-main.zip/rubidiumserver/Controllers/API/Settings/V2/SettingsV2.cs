﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rubidium2018.Database;
using Rubidium2018.RecNet.Generic;
using Rubidium2018.Utils;

namespace Rubidium2018.Controllers.API.Settings.V2;

[Route("api/settings/v2")]
public class SettingsV2(RecDBContext db) : Controller
{
    [HttpGet(""), Authorize]
    public async Task<ActionResult<List<KeyValue>>> GetPlayerSettings()
    {
        var userId = User.GetUserId();
        var player = await db.Players.FirstOrDefaultAsync(x => x.Id == userId);
        
        if (player != null)
            return player.Settings.FromJson<List<KeyValue>>();
        
        return StatusCode(500);
    }

    [HttpPost("{arg}"), Authorize]
    public async Task<IActionResult> SetPlayerSettings(string arg, [FromBody] KeyValue val)
    {
        var userId = User.GetUserId();
        
        var player = await db.Players.FirstOrDefaultAsync(x => x.Id == userId);
        if (player == null) return StatusCode(500);
        
        var settings = player.Settings.FromJson<List<KeyValue>>();
        if (settings == null) return StatusCode(500);

        if (arg == "set")
        {
            var existingEntry = settings.Find(x => x.Key == val.Key);
            if (existingEntry != null)
                existingEntry.Value = val.Value;
            else
                settings.Add(val);
        }

        if (arg == "remove")
        {
            settings.RemoveAll(x => x.Key == val.Key);
        }

        return Ok();
    }
}