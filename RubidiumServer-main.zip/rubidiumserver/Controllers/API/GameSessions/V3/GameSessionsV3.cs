﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rubidium2018.Database;
using Rubidium2018.RecNet.Matchmaking.Enums;
using Rubidium2018.RecNet.Matchmaking.GameSessions;
using Rubidium2018.RecNet.Matchmaking.GameSessions.Requests;
using Rubidium2018.RecNet.Matchmaking.GameSessions.Responses;
using Rubidium2018.RecNet.Matchmaking.Photon;
using Rubidium2018.RecNet.Rooms;
using Rubidium2018.Utils;

namespace Rubidium2018.Controllers.API.GameSessions.V3;

[Route("api/gamesessions/v3")]
public class GameSessionsV3(RecDBContext db) : Controller
{
    [HttpPost("joinroom"), Authorize]
    public async Task<ActionResult<JoinGameSessionResponse>> JoinRoom([FromBody] JoinRoomRequest request)
    {
        var userId = User.GetUserId();
        
        var room = await db.Rooms.FirstOrDefaultAsync(x => x.Name == request.RoomName);
        if (room == null) return StatusCode(500);

        var roomScene = await db.RoomScenes.FirstOrDefaultAsync(x => x.RoomId == room.RoomId);
        if (roomScene == null) return StatusCode(500);

        GameSession? session = null;
        
        if (!RecDB.DoesGameSessionExistForRoom(request.RoomName))
        {
            session = RecDB.CreateNewGameSession(new GameSession
            {
                Name = request.RoomName,
                DataBlobName = roomScene.DataBlobName,
                Private = request.Private,
                PlayersInInstance = new(),
                GameInProgress = false,
                PhotonRegionId = Enum.Parse<CloudRegionCode>(request.RegionPings[0].RegionId), // hopes and prayers yo
                RoomSceneId = roomScene.RoomSceneId
            });
        }
        else
        {
            session = RecDB.GetRandomGameSession(request.RoomName);
        }
        
        await RecDB.SetPlayerGameSession(session.GameSessionId, userId.Value);

        return new JoinGameSessionResponse
        {
            GameSession = session,
            Result = JoinGameErrorCode.Success,
            RoomDetails = null // replace
        };
    }
}