﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rubidium2018.Database;
using Rubidium2018.RecNet.Players.Avatars;
using Rubidium2018.Utils;

namespace Rubidium2018.Controllers.API.Avatar.V3;

[Route("api/avatar/v3")]
public class AvatarV3(RecDBContext db) : Controller
{
    [HttpGet("saved"), Authorize]
    public async Task<ActionResult<List<SavedOutfit>>> GetSavedOutfits()
    {
        var userId = User.GetUserId();

        var player = await db.Players.AsNoTracking().FirstOrDefaultAsync(x => x.Id == userId);
        if (player == null) return StatusCode(500);

        return player.Outfits.FromJson<List<SavedOutfit>>();
    }
    
    [HttpPost("saved/set"), Authorize]
    public async Task<IActionResult> SetSavedOutfit([FromBody] SavedOutfit outfit)
    {
        var userId = User.GetUserId();

        var player = await db.Players.FirstOrDefaultAsync(x => x.Id == userId);
        if (player == null) return StatusCode(500);

        var outfits = player.Outfits.FromJson<List<SavedOutfit>>();
        if (outfits == null) return StatusCode(500);

        var matchingSlot = outfits.FindIndex(x => x.Slot == outfit.Slot);
        if (matchingSlot >= 0)
            outfits[matchingSlot] = outfit;
        else
            outfits.Add(outfit);

        player.Outfits = outfits.ToJson();

        await db.SaveChangesAsync();

        return Ok();
    }
}