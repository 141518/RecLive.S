﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rubidium2018.Database;
using Rubidium2018.Utils;

namespace Rubidium2018.Controllers.API.Avatar.V2;

[Route("api/avatar/v2")]
public class AvatarV2(RecDBContext db) : Controller
{
    [HttpGet(""), Authorize]
    public async Task<ActionResult<RecNet.Players.Avatars.Avatar?>> GetPlayerAvatar()
    {
        var userId = User.GetUserId();

        var player = await db.Players.AsNoTracking().FirstOrDefaultAsync(x => x.Id == userId);
        return player?.Avatar.FromJson<RecNet.Players.Avatars.Avatar>();
    }

    [HttpPost("set"), Authorize]
    public async Task<IActionResult> SetPlayerAvatar([FromBody] RecNet.Players.Avatars.Avatar avatar)
    {
        var userId = User.GetUserId();

        var player = await db.Players.FirstOrDefaultAsync(x => x.Id == userId);
        if (player == null) return StatusCode(500);

        player.Avatar = avatar.ToJson();
        
        await db.SaveChangesAsync();

        return Ok();
    }

    [HttpGet("gifts"), Authorize]
    public List<object> GetPendingGifts()
    {
        return [];
    }
}