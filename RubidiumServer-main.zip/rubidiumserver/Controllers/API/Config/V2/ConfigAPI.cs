﻿using Microsoft.AspNetCore.Mvc;
using Rubidium2018.RecNet.RecRoom.Config;

namespace Rubidium2018.Controllers.API.Config.V2
{
	[Route("api/config/v2")]
	public class ConfigAPI : Controller
	{
		[HttpGet("")]
		public ActionResult<RecRoomConfig> GetConfig()
		{
			RecRoomConfig.TryRefreshDaily();
			return RecRoomConfig.Active;
		}
	}
}
