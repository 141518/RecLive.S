﻿using Microsoft.AspNetCore.SignalR;

namespace Rubidium2018.Controllers.Notify
{
	public class NotifyHub : Hub
	{
	}
}
