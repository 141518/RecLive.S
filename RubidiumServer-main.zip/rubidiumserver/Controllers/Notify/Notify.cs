﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Rubidium2018.Database;
using Rubidium2018.RecNet.Notifications;

namespace Rubidium2018.Controllers.Notify
{
	public class Notify
	{
		public static IDbContextFactory<RecDBContext> DbFactory;
		public static IHubContext<NotifyHub> Context;
		public static List<HubClient> Clients = new();
		
		public static async Task SendMessage(long Targetid, Message msg) { }
		public static async Task SendNotify(long Targetid, Notification msg) { }
	}
}
