﻿using Microsoft.EntityFrameworkCore;
using Rubidium2018.RecNet.Matchmaking;
using Rubidium2018.RecNet.Rooms;
using Rubidium2018.Rubidium.Auth.CachedLogins;
using Rubidium2018.Rubidium.Players;
using Rubidium2018.Rubidium.Rooms;

namespace Rubidium2018.Database
{
	public class RecDBContext : DbContext
	{
		// Player
		public DbSet<RBPlayer> Players;
		public DbSet<RbCachedLogin> CachedLogins;
		
		// Rooms
		public DbSet<RBRoom> Rooms;
		public DbSet<RoomScene> RoomScenes;
	}
}
