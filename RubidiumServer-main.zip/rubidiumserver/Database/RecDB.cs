﻿using Microsoft.EntityFrameworkCore;
using Rubidium2018.RecNet.Matchmaking;
using Rubidium2018.RecNet.Matchmaking.GameSessions;
using Rubidium2018.RecNet.Players.Progression;
using Rubidium2018.Utils;

namespace Rubidium2018.Database
{
	// use for temporary stuff
	public class RecDB
	{
		public static IDbContextFactory<RecDBContext> DbFactory { get; set; }
		
		internal static Dictionary<long, GameSession> ActiveGameSessions = new();
		internal static long SessionCounter = 0;

		public static long GetNewGameSessionId()
		{
			return SessionCounter++;
		}

		public static bool DoesGameSessionExistForRoom(string name)
		{
			return ActiveGameSessions.FirstOrDefault(x => x.Value.Name == name && !x.Value.IsSessionFull).Value != null;
		}

		// nullable but DoesGameSessionExistForRoom exists for a reason
		public static GameSession? GetRandomGameSession(string name)
		{
			var sessions = ActiveGameSessions.Where(x => x.Value.Name == name && !x.Value.IsSessionFull).ToList();
			if (!sessions.Any()) return null;
			
			return sessions[Random.Shared.Next(sessions.Count)].Value;
		}
		
		public static GameSession CreateNewGameSession(GameSession session)
		{
			session.GameSessionId = GetNewGameSessionId();
			ActiveGameSessions.Add(session.GameSessionId, session);
			return session;
		}

		public static async Task<bool> SetPlayerGameSession(long gameSessionId, long playerId)
		{
			await using var db = await DbFactory.CreateDbContextAsync();
			
			if (!ActiveGameSessions.ContainsKey(gameSessionId)) return false;
			
			var player = await db.Players.FirstOrDefaultAsync(x => x.Id == playerId);
			if (player == null) return false;

			// clean up player id from previous sessions, in case i forget again
			var sessionsWithPlayer =
				ActiveGameSessions.Where(x => x.Value.PlayersInInstance.Contains(playerId)).ToList();
			foreach (var session in sessionsWithPlayer)
			{
				session.Value.PlayersInInstance.Remove(playerId);
			}

			var presence = player.GetPresence();
			presence.GameSession = ActiveGameSessions[gameSessionId];
			player.Presence = presence.ToJson();
			
			await db.SaveChangesAsync();

			return true;
		}

		public static Objective[][] WeeklyObjectives { get; set; } = { };
		public static Objective[][] DailyObjectives { get; set; } = { };
	}
}
