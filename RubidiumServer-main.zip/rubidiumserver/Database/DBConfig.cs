﻿namespace Rubidium2018.Database
{
	public static class DBConfig
	{
		public const string JwtKey = "REPLACE_ME";
	}
}
