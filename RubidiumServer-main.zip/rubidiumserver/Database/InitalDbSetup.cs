﻿namespace Rubidium2018.Database
{
	public static class InitalDbSetup
	{
		public static void Run()
		{

		}

		private static void AddRoom()
		{

		}
	}
}
