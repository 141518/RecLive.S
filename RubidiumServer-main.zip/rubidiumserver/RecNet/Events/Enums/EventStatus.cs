﻿namespace Rubidium2018.RecNet.Events.Enums
{
	public enum EventStatus
	{
		Unknown = -1,
		Open = 0,
		NotStarted = 1,
		AlreadyFinished = 2,
		CreatorNotReady = 3,
		GameSessionFull = 4
	}
}
