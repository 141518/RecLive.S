﻿using Rubidium2018.RecNet.Events.Enums;

namespace Rubidium2018.RecNet.Events
{
	public class Event
	{
		public long EventId { get; set; }

		public string Name { get; set; }

		public string Description { get; set; }

		public DateTime StartTime { get; set; }

		public DateTime EndTime { get; set; }

		public string PosterImageName { get; set; }

		public long CreatorPlayerId { get; set; }

		public EventStatus Status { get; set; }

		public bool IsHappeningNow
		{
			get
			{
				DateTime utcNow = DateTime.UtcNow;
				return StartTime < utcNow && utcNow < EndTime;
			}
		}

	}
}
