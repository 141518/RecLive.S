﻿using Rubidium2018.RecNet.Platforms.Enums;

namespace Rubidium2018.RecNet.Platforms
{
	public class PlatformMapping
	{
		public PlatformType Platform { get; private set; }
		public ulong PlatformId { get; private set; }
	}
}
