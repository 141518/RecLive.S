﻿namespace Rubidium2018.RecNet.Platforms.Enums
{
	public enum PlatformType
	{
		All = -1,
		Steam = 0,
		Oculus = 1,
		PlayStation = 2,
		Microsoft = 3,
		HeadlessBot = 4
	}

	[Flags]
	public enum PlatformMask
	{
		None = 0,
		Steam = 1,
		Oculus = 2,
		PlayStation = 4,
		Microsoft = 8,
		HeadlessBot = 0x10,
		All = -1
	}

	public enum HardwareType
	{
		VIVE = 0,
		OCULUS = 1,
		PSVR = 2,
		MICROSOFT_VR = 3,
		DESKTOP_NO_VR = 4,
		SANTA_CRUZ = 5
	}
}
