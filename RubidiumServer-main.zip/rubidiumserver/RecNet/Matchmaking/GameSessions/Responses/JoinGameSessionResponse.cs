﻿using Rubidium2018.RecNet.Matchmaking.Enums;
using Rubidium2018.RecNet.Rooms;

namespace Rubidium2018.RecNet.Matchmaking.GameSessions.Responses;

public class JoinGameSessionResponse
{
    public JoinGameErrorCode Result { get; set; }

    public GameSession GameSession { get; set; }

    public RoomDetails RoomDetails { get; set; }
}