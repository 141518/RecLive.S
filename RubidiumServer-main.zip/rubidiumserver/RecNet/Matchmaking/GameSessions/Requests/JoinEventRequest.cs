﻿namespace Rubidium2018.RecNet.Matchmaking.GameSessions.Requests;

public class JoinEventRequest: BaseJoinRequest
{
    public long EventId { get; set; }
}