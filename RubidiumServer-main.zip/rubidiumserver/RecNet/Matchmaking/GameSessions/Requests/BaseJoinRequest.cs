﻿using Rubidium2018.RecNet.Matchmaking.Photon;

namespace Rubidium2018.RecNet.Matchmaking.GameSessions.Requests;

public class BaseJoinRequest
{
    public List<long> ExpectedPlayerIds { get; set; } = new();

    public List<CloudRegionPing> RegionPings { get; set; } = new();

    public List<string> RoomTags { get; set; } = new();
}