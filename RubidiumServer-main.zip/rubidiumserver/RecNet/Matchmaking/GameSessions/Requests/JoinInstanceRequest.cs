﻿namespace Rubidium2018.RecNet.Matchmaking.GameSessions.Requests;

public class JoinInstanceRequest : BaseJoinRequest
{
    public long GameSessionId { get; set; }
}