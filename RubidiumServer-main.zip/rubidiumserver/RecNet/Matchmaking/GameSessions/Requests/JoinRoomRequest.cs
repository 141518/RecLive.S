﻿using Rubidium2018.RecNet.Matchmaking.Enums;

namespace Rubidium2018.RecNet.Matchmaking.GameSessions.Requests;

public class JoinRoomRequest : BaseJoinRequest
{
    public string RoomName { get; set; } = "^dormroom";

    public string SceneName { get; set; } = "";

    public bool Private { get; set; }

    public AdditionalPlayerJoinMode AdditionalPlayerJoinMode { get; set; }
}