﻿namespace Rubidium2018.RecNet.Matchmaking.GameSessions.Requests;

public class JoinPlayerRequest
{
    public long PlayerId { get; set; }
}