﻿using System.Text.Json.Serialization;
using Rubidium2018.RecNet.Matchmaking.Enums;
using Rubidium2018.RecNet.Rooms.Enums;

namespace Rubidium2018.RecNet.Matchmaking.GameSessions
{
	public class GameSession
	{
		public static GameSession OfflineGameSession = new GameSession
		{
			GameSessionId = -1L,
			Name = "^dormroom",
			PhotonRegionId = CloudRegionCode.none,
			PhotonRoomId = "offline",
			RoomSceneId = -1L,
			RoomId = -1L,
			IsSandbox = false,
			DataBlobName = null,
			Private = true,
			MaxCapacity = 1,
			IsFull = true
		};
		
		internal bool IsSessionFull => PlayersInInstance.Count >= MaxCapacity;

		public long GameSessionId { get; set; }

		public CloudRegionCode PhotonRegionId { get; set; }

		public string PhotonRoomId { get; set; }

		public string Name { get; set; }

		public long RoomId { get; set; }

		public long RoomSceneId { get; set; }

		public RoomSceneLocations Location { get; set; }

		public bool IsSandbox { get; set; }

		public string? DataBlobName { get; set; }

		public long? PlayerEventId { get; set; }

		public bool Private { get; set; }

		public bool GameInProgress { get; set; }

		public int MaxCapacity { get; set; }

		public bool IsFull { get; set; }
		
		[JsonIgnore]
		public List<long> PlayersInInstance { get; set; }
	}
}
