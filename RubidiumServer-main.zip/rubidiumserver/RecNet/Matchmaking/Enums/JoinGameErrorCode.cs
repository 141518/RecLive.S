﻿namespace Rubidium2018.RecNet.Matchmaking.Enums;

public enum JoinGameErrorCode
{
    Success = 0,
    NoSuchGame = 1,
    PlayerNotOnline = 2,
    InsufficientSpace = 3,
    EventNotStarted = 4,
    EventAlreadyFinished = 5,
    EventCreatorNotReady = 6,
    BlockedFromRoom = 7,
    ProfileLocked = 8,
    NoBirthday = 9,
    MarkedForDelete = 10,
    JuniorNotAllowed = 11,
    Banned = 12,
    AlreadyInBestGameSession = 13,
    ScreenModeNotAllowed = 14,
    VRModeNotAllowed = 15,
    UpdateRequired = 16,
    AlreadyInTargetGameSession = 17,
    RegistrationRequired = 18,
    NoSuchRoom = 20,
    RoomCreatorNotReady = 21,
    RoomIsNotActive = 22,
    RoomBlockedByCreator = 23,
    RoomBlockingCreator = 24,
    RoomIsPrivate = 25,
    PlayerTypeNotSupported = 30
}