﻿namespace Rubidium2018.RecNet.Matchmaking.Enums;

public enum AdditionalPlayerJoinMode
{
    Invite = 0,
    AutoFollow = 1
}