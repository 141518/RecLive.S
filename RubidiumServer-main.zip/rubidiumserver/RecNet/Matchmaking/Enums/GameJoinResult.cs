﻿namespace Rubidium2018.RecNet.Matchmaking.Enums;

public enum GameJoinResult
{
    Success = 0,
    FailedToConnectToRegion = 1,
    FailedToConnectToRoom = 2,
    FailedToSpawnPlayer = 3
}