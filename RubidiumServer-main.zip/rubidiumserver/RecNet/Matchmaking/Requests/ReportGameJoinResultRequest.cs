﻿using Rubidium2018.RecNet.Matchmaking.Enums;

namespace Rubidium2018.RecNet.Matchmaking.Requests;

public class ReportGameJoinResultRequest
{
    public long GameSessionId { get; set; }

    public string RegionId { get; set; }

    public string RoomId { get; set; }

    public GameJoinResult Result { get; set; }

    public long? RecRoomId { get; set; }

    public long MasterPlayerId { get; set; }
}