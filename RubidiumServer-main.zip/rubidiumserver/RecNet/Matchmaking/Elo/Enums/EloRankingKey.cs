﻿namespace Rubidium2018.RecNet.Matchmaking.Elo.Enums
{
	public enum EloRankingKey
	{
		Activity = 0,
		ActivityLevel = 1
	}
}
