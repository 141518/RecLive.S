﻿namespace Rubidium2018.RecNet.Matchmaking.Elo
{
	public class PlayersEloUpdateDTO
	{
		public string ActivityLevel { get; set; }

		public List<PlayerScoreUpdate> PlayerScoreUpdates { get; set; } = new();
	}
}
