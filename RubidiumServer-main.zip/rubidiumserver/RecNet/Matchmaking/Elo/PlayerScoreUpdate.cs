﻿namespace Rubidium2018.RecNet.Matchmaking.Elo
{
	public class PlayerScoreUpdate
	{
		public int Team { get; set; }

		public long PlayerId { get; set; }

		public int GameScore { get; set; }
	}
}
