﻿namespace Rubidium2018.RecNet.Matchmaking.Photon;

public class CloudRegionPing
{
    public string RegionId { get; set; } = "us";
    public int Ping { get; set; } = 0;
}