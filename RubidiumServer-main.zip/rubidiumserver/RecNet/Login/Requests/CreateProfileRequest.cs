﻿namespace Rubidium2018.RecNet.Login.Requests;

public class CreateProfileRequest : BaseLoginRequest
{
    public string Birthday { get; set; }
    public string Email { get; set; }
}