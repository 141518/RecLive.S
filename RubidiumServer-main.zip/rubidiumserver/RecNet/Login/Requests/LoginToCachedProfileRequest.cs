﻿namespace Rubidium2018.RecNet.Login.Requests;

public class LoginToCachedProfileRequest : BaseLoginRequest
{
    public long PlayerId { get; set; }
}