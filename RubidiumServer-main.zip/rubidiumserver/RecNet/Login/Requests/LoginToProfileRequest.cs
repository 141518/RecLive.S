﻿namespace Rubidium2018.RecNet.Login.Requests;

public class LoginToProfileRequest : BaseLoginRequest
{
    public string Username { get; set; }

    public string Password { get; set; }

    public bool CacheLogin { get; set; } 
}