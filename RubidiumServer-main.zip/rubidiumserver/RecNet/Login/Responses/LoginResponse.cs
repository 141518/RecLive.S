﻿using Rubidium2018.RecNet.Platforms.Enums;
using Rubidium2018.RecNet.Players;

namespace Rubidium2018.RecNet.Login.Responses;

public class LoginResponse
{
    public Profile Player { get; set; }

    public string Token { get; set; }

    public string Error { get; set; }

    public bool FirstLoginOfTheDay { get; set; }

    public long AnalyticsSessionId { get; set; }

    public PlatformMask CachedPlatformMask { get; set; }
}