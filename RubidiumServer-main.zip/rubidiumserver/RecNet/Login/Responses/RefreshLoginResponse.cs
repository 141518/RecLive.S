﻿namespace Rubidium2018.RecNet.Login.Responses;

public class RefreshLoginResponse
{
    public string Token { get; set; }
}