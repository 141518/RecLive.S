﻿namespace Rubidium2018.RecNet.Rooms.Enums;

public enum RoomAccessibility
{
    Private = 0,
    Public = 1,
    Unlisted = 2
}