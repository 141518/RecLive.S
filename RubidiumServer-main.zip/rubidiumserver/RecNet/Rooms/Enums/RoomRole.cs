﻿namespace Rubidium2018.RecNet.Rooms.Enums
{
	public enum RoomRole
	{
		Guest = 0,
		Host = 1,
		CoOwner = 2,
		Creator = 3
	}
}
