﻿namespace Rubidium2018.RecNet.Rooms.Enums;

public enum RoomState
{
    Active = 0,
    PendingJunior = 11,
    Moderation_PendingReview = 100,
    Moderation_Closed = 101,
    MarkedForDelete = 1000
}