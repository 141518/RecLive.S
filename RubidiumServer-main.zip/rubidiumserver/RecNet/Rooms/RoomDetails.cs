﻿using Rubidium2018.RecNet.Rooms.Enums;

namespace Rubidium2018.RecNet.Rooms
{
    public class RoomDetails
    {
        public static readonly RoomDetails OfflineRoomDetails = new RoomDetails
        {
            Room = Room.OfflineRoom,
            Scenes = new List<RoomScene> { RoomScene.OfflineRoomScene },
            CoOwnerIds = new List<int>(),
            InvitedCoOwnerIds = new List<int>(),
            HostIds = new List<int>(),
            InvitedHostIds = new List<int>(),
            CheerCount = 0,
            FavoriteCount = 0,
            VisitCount = 0
        };
        
        public List<string> AllTags = new List<string>();

        public List<string> AutoTags = new List<string>();

        public List<string> PlayerAddedTags = new List<string>();

        public List<string> AgTags = new List<string>();

        public Room Room { get; set; }

        public List<RoomScene> Scenes { get; set; } = new();

        public List<int> CoOwnerIds { get; set; } = new();

        public List<int> InvitedCoOwnerIds { get; set; } = new();

        public List<int> HostIds { get; set; } = new();

        public List<int> InvitedHostIds { get; set; } = new();

        public int CheerCount { get; set; }

        public int FavoriteCount { get; set; }

        public int VisitCount { get; set; }

        public RoomRole LocalPlayerRole { get; set; }
    }
}
