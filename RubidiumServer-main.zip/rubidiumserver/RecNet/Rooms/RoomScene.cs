﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Rubidium2018.RecNet.Rooms.Enums;

namespace Rubidium2018.RecNet.Rooms;

public class RoomScene
{
    public static readonly RoomScene OfflineRoomScene = new RoomScene
    {
        RoomSceneId = -1L,
        RoomId = -1L,
        Location = RoomSceneLocations.DORM_ROOM,
        Name = "DormRoom",
        IsSandbox = false,
        DataBlobName = string.Empty,
        MaxPlayers = 1,
        CanMatchmakeInto = false,
        DataModifiedAt = DateTime.UtcNow
    };
    
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long RoomSceneId { get; set; }

    public long RoomId { get; set; } = 0;

    public RoomSceneLocations Location { get; set; } = RoomSceneLocations.MAKER_ROOM;

    public string Name { get; set; } = "";

    public bool IsSandbox { get; set; } = true;

    public string DataBlobName { get; set; } = "";

    public int MaxPlayers { get; set; } = 16;

    public bool CanMatchmakeInto { get; set; } = true;

    public DateTime DataModifiedAt { get; set; } = DateTime.Now;
}