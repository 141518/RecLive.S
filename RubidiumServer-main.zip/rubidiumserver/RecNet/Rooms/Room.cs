﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Rubidium2018.RecNet.Rooms.Enums;
using Rubidium2018.Rubidium.Images;

namespace Rubidium2018.RecNet.Rooms;

public class Room
{
    public static readonly Room OfflineRoom = new Room
    {
        RoomId = -1L,
        Name = "DormRoom",
        Description = "",
        CreatorPlayerId = 0,
        State = RoomState.Active,
        Accessibility = RoomAccessibility.Unlisted,
        SupportsLevelVoting = false,
        IsAGRoom = true,
        CloningAllowed = false,
        SupportsScreens = true,
        SupportsWalkVR = true,
        SupportsTeleportVR = true
    };
    
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public long RoomId { get; set; }

    public string Name { get; set; }

    public string Description { get; set; }

    public string ImageName { get; set; }

    public long CreatorPlayerId { get; set; }

    public RoomState State { get; set; }

    public RoomAccessibility Accessibility { get; set; }

    public bool SupportsLevelVoting { get; set; }

    public bool IsAGRoom { get; set; }

    public bool CloningAllowed { get; set; }

    public bool SupportsScreens { get; set; }

    public bool SupportsWalkVR { get; set; }

    public bool SupportsTeleportVR { get; set; }

    public bool IsPublished
    {
        get
        {
            return Accessibility != RoomAccessibility.Private;
        }
    }

    public bool IsActive
    {
        get
        {
            return State == RoomState.Active /*|| (State == RoomState.Moderation_PendingReview && SessionManager.IsDeveloper)*/;
        }
    }

    public bool HasDefaultImage
    {
        get
        {
            return ImageName == RBDefaultImages.DefaultRoomImage;
        }
    }
}