﻿namespace Rubidium2018.RecNet.Messages.Enums
{
	public enum MessageType
	{
		GameInvite = 0,
		GameInviteDeclined = 1,
		GameJoinFailed = 2,
		PartyActivitySwitch = 3,
		FriendInvite = 4,
		VoteToKick = 5,
		RequestGameInvite = 10,
		RequestGameInviteDeclined = 11,
		FriendStatusOnline = 20,
		TextMessage = 30,
		FriendRequestAccepted = 40,
		PlayerCheer = 50,
		PlayerCheerAnonymous = 51,
		RoomCoOwnerAdded = 60,
		RoomCoOwnerRemoved = 61,
		RoomCoOwnerInvited = 62,
		CreatorPublishedNewRoom = 70,
		PlayerEventInvitation = 81,
		CoachMessage = 100
	}
}
