﻿using Rubidium2018.RecNet.Messages.Enums;

namespace Rubidium2018.RecNet.Messages
{
	public class Message
	{
		public long Id { get; set; }

		public long FromPlayerId { get; set; }

		public DateTime SentTime { get; set; }

		public MessageType Type { get; set; }

		public string Data { get; set; }

		public long? RoomId { get; set; }

		public long? PlayerEventId { get; set; }

		public object Details { get; set; }

		public DateTime DeserializedAt { get; set; }
	}
}
