﻿namespace Rubidium2018.RecNet.Generic;

public class KeyValue
{
    public string Key { get; set; }
    public string Value { get; set; }
}