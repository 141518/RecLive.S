﻿using Rubidium2018.RecNet.Platforms.Enums;

namespace Rubidium2018.RecNet.PlatformLogin.DTOs;

public class RemoveCachedLoginDTO
{
    public PlatformType Platform { get; set; }
    public string PlatformId  { get; set; }
}