﻿using Rubidium2018.RecNet.Platforms.Enums;

namespace Rubidium2018.RecNet.Players.Equipment
{
	public class Equipment
	{
		public string PrefabName { get; set; }

		public string ModificationGuid { get; set; }

		public int UnlockedLevel { get; set; }

		public PlatformMask PlatformMask { get; set; } = PlatformMask.All;

		public bool IsPlatformLocked { get; private set; }
	}
}
