﻿using Rubidium2018.RecNet.Platforms;
using System.Text.Json.Serialization;

namespace Rubidium2018.RecNet.Players
{
	public class Profile
	{
		public long Id { get; set; }

		public string Username { get; set; } = string.Empty;
		public string DisplayName { get; set; } = string.Empty;
		public string ProfileImageName { get; set; } = "default";
		public string Bio { get; set; } = string.Empty;

		public int XP { get; set; } = 0;
		public int Level { get; set; } = 1;

		public bool JuniorProfile { get; set; } = false;
		public bool ForceJuniorImages { get; set; } = false;
		public bool PendingJunior { get; set; } = false;
		public bool HasBirthday { get; set; } = false;

		[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
		public bool? AvoidJuniors { get; set; }

		public bool CanReceiveInvites { get; set; } = false;

		public bool Developer { get; set; } = false;

		public Reputation PlayerReputation { get; set; } = new();

		public PlatformMapping PlatformId { get; set; } = new();
	}
}
