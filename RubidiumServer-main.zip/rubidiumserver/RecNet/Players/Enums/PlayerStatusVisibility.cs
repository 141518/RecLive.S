﻿namespace Rubidium2018.RecNet.Players.Enums
{
	public enum PlayerStatusVisibility
	{
		Public = 0,
		FriendsOnly = 1,
		FavoriteFriendsOnly = 2,
		Offline = 3
	}
}
