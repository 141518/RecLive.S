﻿namespace Rubidium2018.RecNet.Players.Enums
{
	public enum DisplayMode
	{
		UNINITIALIZED = 0,
		VR = 1,
		SCREEN = 2
	}

	public enum PlayerType
	{
		UNINITIALIZED = 0,
		VR_WALK = 1,
		VR_TELEPORT = 2,
		SCREEN = 3
	}
}
