﻿namespace Rubidium2018.RecNet.Players.Avatars;

public class SavedOutfit
{
    public int Slot { get; set; }

    public string PreviewImageName { get; set; }

    public string OutfitSelections { get; set; }

    public string FaceFeatures { get; set; }

    public string SkinColor { get; set; }

    public string HairColor { get; set; }
}