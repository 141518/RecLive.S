﻿using Rubidium2018.RecNet.Platforms.Enums;
using Rubidium2018.RecNet.Players.Avatars.Gifts.Enums;
using Rubidium2018.RecNet.Storefront.Currency.Enums;
using System.Text.Json.Serialization;

namespace Rubidium2018.RecNet.Players.Avatars.Gifts
{
	public class GiftPackage
	{
		public long Id { get; private set; }

		public string ConsumableItemDesc { get; private set; }

		public string AvatarItemDesc { get; private set; }

		public string EquipmentPrefabName { get; private set; }

		public string EquipmentModificationGuid { get; private set; }

		public CurrencyType CurrencyType { get; private set; }

		public int Currency { get; private set; }

		public int Xp { get; private set; }

		public int Level { get; private set; }

		[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
		public GiftContext? GiftContext { get; private set; } // defaults to .Common in rr

		[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
		public GiftRarity? GiftRarity { get; private set; }

		[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
		public string? Message { get; set; }

		public PlatformType Platform { get; set; }
	}
}
