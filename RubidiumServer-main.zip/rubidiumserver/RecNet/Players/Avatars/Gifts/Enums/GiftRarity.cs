﻿namespace Rubidium2018.RecNet.Players.Avatars.Gifts.Enums
{
	public enum GiftRarity
	{
		None = -1,
		Common = 0,
		Uncommon = 10,
		Rare = 20,
		Epic = 30,
		Legendary = 50
	}
}
