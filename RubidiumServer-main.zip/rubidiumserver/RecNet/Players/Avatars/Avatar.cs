﻿namespace Rubidium2018.RecNet.Players.Avatars;

public class Avatar
{
    public string OutfitSelections { get; set; }

    public string FaceFeatures { get; set; }

    public string SkinColor { get; set; }

    public string HairColor { get; set; }
}