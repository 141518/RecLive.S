﻿namespace Rubidium2018.RecNet.Players.Presence.Responses
{
	public class HeartbeatResponse
	{
		public string Error { get; set; } = string.Empty;
	}
}
