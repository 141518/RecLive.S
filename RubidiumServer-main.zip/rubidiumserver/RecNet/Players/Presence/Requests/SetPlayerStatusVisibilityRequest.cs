﻿using Rubidium2018.RecNet.Players.Enums;

namespace Rubidium2018.RecNet.Players.Presence.Requests
{
	public class SetPlayerStatusVisibilityRequest
	{
		public PlayerStatusVisibility StatusVisibility { get; set; }
	}
}
