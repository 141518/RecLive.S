﻿namespace Rubidium2018.RecNet.Players.Presence.Requests
{
	public class RemotePlayerDisconnectRequest
	{
		public long PlayerId { get; set; }
		public long GameSessionId { get; set; }
	}
}
