﻿using Rubidium2018.RecNet.Players.Enums;

namespace Rubidium2018.RecNet.Players.Presence.Requests
{
	public class SetPlayerTypeRequest
	{
		public PlayerType PlayerType { get; set; }
	}
}
