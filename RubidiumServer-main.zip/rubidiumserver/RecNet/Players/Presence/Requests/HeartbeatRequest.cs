﻿namespace Rubidium2018.RecNet.Players.Presence.Requests
{
	public class HeartbeatRequest
	{
		public string LoginLockToken { get; set; }
		public long GameSessionId { get; set; }
	}
}
