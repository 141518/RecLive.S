﻿using Rubidium2018.RecNet.Matchmaking.GameSessions;
using Rubidium2018.RecNet.Players.Enums;

namespace Rubidium2018.RecNet.Players.Presence
{
	public class PlayerPresence
	{
		public long PlayerId { get; set; }

		public bool IsOnline { get; set; } = false;
 
		public GameSession GameSession { get; set; } = GameSession.OfflineGameSession;

		public PlayerType PlayerType { get; set; } = PlayerType.UNINITIALIZED;

		public PlayerStatusVisibility StatusVisibility { get; set; } = PlayerStatusVisibility.Public;
	}
}
