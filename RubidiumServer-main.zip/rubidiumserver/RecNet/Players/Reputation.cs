﻿using System.Text.Json.Serialization;

namespace Rubidium2018.RecNet.Players
{
	public class Reputation
	{
		private const float MIN_GOOD_NOTERIETY = -2.5f;

		[JsonIgnore]
		public bool IsInGoodStanding
		{
			get
			{
				return Noteriety >= -2.5f;
			}
		}

		public float Noteriety { get; set; } = 0;

		public PlayerCheering.CheerCategory? SelectedCheer { get; set; } = PlayerCheering.CheerCategory.General;

		public int CheerCredit { get; set; } = 0;

		public int CheerGeneral { get; set; } = 0;

		public int CheerHelpful { get; set; } = 0;

		public int CheerCreative { get; set; } = 0;

		public int CheerGreatHost { get; set; } = 0;

		public int CheerSportsman { get; set; } = 0;

		public int SubscriberCount { get; set; } = 0;

		public int SubscribedCount { get; set; } = 0;
	}
}
