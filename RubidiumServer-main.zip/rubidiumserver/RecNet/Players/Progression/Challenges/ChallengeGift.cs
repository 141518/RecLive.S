﻿using Rubidium2018.RecNet.Players.Avatars.Gifts.Enums;
using Rubidium2018.RecNet.Storefront.Enums;

namespace Rubidium2018.RecNet.Players.Progression.Challenges
{
	public class ChallengeGift
	{
		public long GiftDropId { get; private set; }

		public string ConsumableItemDesc { get; private set; }

		public string AvatarItemDesc { get; private set; }

		public string EquipmentPrefabName { get; private set; }

		public string EquipmentModificationGuid { get; private set; }

		public StorefrontTypes StorefrontType { get; private set; }

		public int Xp { get; private set; }

		public int Level { get; private set; }

		public GiftContext GiftContext { get; private set; }

		public GiftRarity GiftRarity { get; private set; }
	}
}
