﻿namespace Rubidium2018.RecNet.Players.Progression.Challenges
{
	public class RecNetChallenge
	{
		public int ChallengeId { get; set; }

		public string Name { get; set; }

		public string Config { get; set; }

		public string Description { get; set; }

		public string Tooltip { get; set; }

		public bool Complete { get; set; }

		public int Slot { get; set; }
	}
}
