﻿namespace Rubidium2018.RecNet.Players.Progression.Challenges
{
	public class ChallengeMap
	{
		public int ChallengeMapId { get; set; }

		public string ThemeString { get; set; }

		public int? ThemeId { get; set; }

		public List<RecNetChallenge> Challenges { get; set; }

		public List<ChallengeGift> Gifts { get; set; }

		public DateTime StartAt { get; set; }

		public DateTime EndAt { get; set; }

		public DateTime ServerTime { get; set; }

		public bool CompleteAll { get; set; }
	}
}
