﻿using Rubidium2018.RecNet.Players.Progression.Enums;

namespace Rubidium2018.RecNet.Players.Progression
{
	public class Objective
	{
		public ObjectiveType ObjectiveType = ObjectiveType.Default;

		public int RequiredScore;
	}
}
