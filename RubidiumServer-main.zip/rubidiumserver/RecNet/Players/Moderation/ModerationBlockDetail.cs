﻿using Rubidium2018.RecNet.Players.Moderation.Reporting.Enums;

namespace Rubidium2018.RecNet.Players.Moderation
{
	public class ModerationBlockDetail
	{
		public ReportCategory ReportCategory { get; private set; }

		public int Duration { get; set; }

		public long GameSessionId { get; private set; }

		public string Message { get; private set; }
	}
}
