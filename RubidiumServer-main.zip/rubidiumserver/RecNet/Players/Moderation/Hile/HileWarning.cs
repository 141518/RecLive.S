﻿using Rubidium2018.RecNet.Players.Moderation.Hile.Enums;

namespace Rubidium2018.RecNet.Players.Moderation.Hile
{
	public class HileWarning
	{
		public string Message { get; set; }

		public HileType Type { get; set; }
	}
}
