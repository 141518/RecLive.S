﻿namespace Rubidium2018.RecNet.Players.Moderation.Hile.Enums
{
	public enum HileType
	{
		Obcured = 0,
		Time = 1,
		Inject = 2,
		GiftCount = 3,
		Engine = 4
	}
}
