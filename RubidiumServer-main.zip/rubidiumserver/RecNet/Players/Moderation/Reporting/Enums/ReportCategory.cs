﻿namespace Rubidium2018.RecNet.Players.Moderation.Reporting.Enums
{
	public enum ReportCategory
	{
		Moderator = -1,
		Unknown = 0,
		DEPRECATED_MicrophoneAbuse = 1,
		Harassment = 2,
		Cheating = 3,
		DEPRECATED_ImmatureBehavior = 4,
		AFK = 5,
		Misc = 6,
		Underage = 7,
		VoteKick = 10,
		CoC_Underage = 100,
		CoC_Sexual = 101,
		CoC_Discrimination = 102,
		CoC_Trolling = 103,
		CoC_NameOrProfile = 104,
		IssuingInaccurateReports = 1000
	}
}
