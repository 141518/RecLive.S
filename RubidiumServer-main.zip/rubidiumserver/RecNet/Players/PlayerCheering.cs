﻿namespace Rubidium2018.RecNet.Players
{
	public class PlayerCheering
	{
		public enum CheerCategory
		{
			General = 0,
			Helpful = 10,
			Sportmanship = 20,
			GreatHost = 30,
			Creative = 40
		}
	}
}
