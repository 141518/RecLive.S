﻿namespace Rubidium2018.RecNet.Players.Relationships
{
	public class Relationship
	{
		public enum RelationshipType
		{
			None = 0,
			FriendRequestSent = 1,
			FriendRequestReceived = 2,
			Friend = 3
		}

		public enum ReciprocalStatus
		{
			None = 0,
			Local = 1,
			Remote = 2,
			Mutual = 3
		}

		public long PlayerID { get; set; }

		public RelationshipType Type { get; set; }

		public ReciprocalStatus Muted { get; set; }

		public ReciprocalStatus Ignored { get; set; }

		public ReciprocalStatus Favorited { get; set; }
	}
}
