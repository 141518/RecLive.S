﻿namespace Rubidium2018.RecNet.Storefront.Enums
{
	public enum StorefrontTypes
	{
		None = 0,
		LaserTag = 1,
		RecCenter = 2,
		Watch = 3,
		Quest_LostSkulls = 100,
		Quest_Dracula = 101,
		RecRoyale = 200,
		Cafe = 300,
		Paintball = 400,
		Bowling = 500
	}
}
