﻿namespace Rubidium2018.RecNet.Storefront.Currency.Enums
{
	public enum CurrencyType
	{
		Invalid = 0,
		LaserTagTickets = 1,
		RecCenterTokens = 2,
		LostSkullsGold = 100,
		DraculaSilver = 101,
		RecRoyale_Season1 = 200
	}
}
