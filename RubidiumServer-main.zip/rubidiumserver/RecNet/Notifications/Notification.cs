﻿namespace Rubidium2018.RecNet.Notifications
{
	public class Notification
	{
		public object Id { get; set; }
		public object Msg { get; set; }
	}
}
