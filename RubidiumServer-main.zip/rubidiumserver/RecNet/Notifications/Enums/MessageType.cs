﻿namespace Rubidium2018.RecNet.Notifications.Enums
{
	public enum MessageType
	{
		GameInvite,
		GameInviteDeclined,
		GameJoinFailed,
		PartyActivitySwitch,
		FriendInvite,
		VoteToKick,
		GameInviteV2,
		PartyActivitySwitchV2,
		RequestGameInvite = 10,
		RequestGameInviteDeclined,
		FriendStatusOnline = 20,
		TextMessage = 30,
		FriendRequestAccepted = 40,
		PlayerCheer = 50,
		PlayerCheerAnonymous,
		RoomCoOwnerAdded = 60,
		RoomCoOwnerRemoved,
		RoomCoOwnerInvited,
		CreatorPublishedNewRoom = 70,
		PlayerAttendingEvent = 80,
		PlayerEventInvitation,
		DEPRECATED_GroupInvitation = 90,
		DEPRECATED_PlayerJoinedGroup,
		CoachMessage = 100,
		NewRoomComments = 110,
		PartyUpRequest = 120,
		ClubMemberInvited = 200,
		ClubModeratorInvited,
		ClubCoownerInvited,
		VirtualCreatorAnnouncementRoomPublished = 100000,
		VirtualCreatorAnnouncementInventionPublished,
		VirtualCreatorAnnouncementGeneric,
		VirtualCreatorAnnouncementPlayerEventPublished
	}
}
