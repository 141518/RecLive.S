﻿using Rubidium2018.RecNet.Notifications.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Rubidium2018.RecNet.Notifications
{
	public class Message
	{
		[Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public long Id { get; set; }

		public long FromPlayerId { get; set; }

		[JsonIgnore]
		public long ToPlayerId { get; set; }

		public DateTime SentTime { get; set; }
		public MessageType Type { get; set; }

		public string Data { get; set; } = string.Empty;
		public string Details { get; set; } = string.Empty;

		public long? RoomId { get; set; }
		public long? PlayerEventId { get; set; }
	}
}
