﻿namespace Rubidium2018.RecNet.RecRoom.Config
{
	public class MatchmakingConfigParams
	{
		public float PreferFullRoomsFrequency { get; set; } = 0.5f;

		public float PreferEmptyRoomsFrequency { get; set; } = 0.5f;
	}
}
