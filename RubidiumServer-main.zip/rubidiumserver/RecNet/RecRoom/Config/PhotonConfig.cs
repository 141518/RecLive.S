﻿namespace Rubidium2018.RecNet.RecRoom.Config
{
	public class PhotonConfig
	{
		public bool CrcCheckEnabled { get; set; } = false;

		public bool EnableServerTracingAfterDisconnect { get; set; } = false;
	}
}
