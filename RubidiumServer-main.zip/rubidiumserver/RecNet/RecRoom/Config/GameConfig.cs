﻿using System.Text.Json.Serialization;

namespace Rubidium2018.RecNet.RecRoom.Config
{
	public class GameConfig
	{
		public string Key { get; set; }

		public string Value { get; set; }

		[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
		public DateTime? StartTime { get; set; }

		[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
		public DateTime? EndTime { get; set; }
	}
}
