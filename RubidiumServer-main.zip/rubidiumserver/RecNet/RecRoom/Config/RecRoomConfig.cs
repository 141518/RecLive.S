﻿using Rubidium2018.RecNet.Players.Progression;
using Rubidium2018.Rubidium.Progression;
using System.Text.Json.Serialization;

namespace Rubidium2018.RecNet.RecRoom.Config
{
	public class RecRoomConfig
	{
		[JsonIgnore]
		public static RecRoomConfig Active { get; set; }

		public string MessageOfTheDay { get; set; } = "Welcome to Rec Room!";

		public string CdnBaseUri { get; set; } = "https://rec.net/{0}";

		public MatchmakingConfigParams MatchmakingParams { get; set; } = new();

		public Dictionary<int, int> LevelProgressionMap { get; set; } = new();

		public Objective[][] DailyObjectives { get; set; } = { };

		public PhotonConfig PhotonConfig { get; set; } = new();

		public ServerMaintenanceDTO ServerMaintenance { get; set; } = new();

		private static DateTime LastDailyRefresh = DateTime.Now;
		public static void TryRefreshDaily()
		{
			if (DateTime.Now > LastDailyRefresh.AddDays(1))
			{
				Active.DailyObjectives = [
					[RBPresetDailys.CreateRandomObjective(), RBPresetDailys.CreateRandomObjective(), RBPresetDailys.CreateRandomObjective()]
					];
			}
		}
	}
}
