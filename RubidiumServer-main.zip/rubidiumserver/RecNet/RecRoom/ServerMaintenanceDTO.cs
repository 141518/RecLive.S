﻿namespace Rubidium2018.RecNet.RecRoom
{
	public class ServerMaintenanceDTO
	{
		public int StartsInMinutes { get; set; } = 0;
	}
}
