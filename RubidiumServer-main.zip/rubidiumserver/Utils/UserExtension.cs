﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Rubidium2018.Utils;

public static class UserExtension
{
    public static long? GetUserId(this ClaimsPrincipal req)
    {
        string? userIdStr = req.FindFirstValue(ClaimTypes.NameIdentifier);
        if (userIdStr == null) return null;
        return long.Parse(userIdStr);
    }
}