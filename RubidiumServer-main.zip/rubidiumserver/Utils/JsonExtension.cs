﻿using System.Text.Json.Nodes;
using System.Text.Json;

namespace Rubidium2018.Utils
{
	public static class JsonExtension // straight from uranium :)
	{
		public static T? FromJson<T>(this string json)
		{
			return JsonSerializer.Deserialize<T>(json);
		}
		public static string ToJson(this object val)
		{
			return JsonSerializer.Serialize(val);
		}

		public static T Get<T>(this JsonNode node, string key, T fallback = default!) // use when parsing json from a discord bot!!
		{
			try
			{
				var value = node?[key];

				if (value is null)
					return fallback;

				var obj = value.GetValue<object>();

				if (typeof(T) == typeof(bool))
				{
					if (obj is int i) return (T)(object)(i != 0);
					if (obj is string s) return (T)(object)(s == "1" || s.ToLower() == "true");
				}

				return value.GetValue<T>();
			}
			catch
			{
				return fallback;
			}
		}
	}
}
