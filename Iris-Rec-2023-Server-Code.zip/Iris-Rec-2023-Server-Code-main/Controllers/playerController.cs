﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class playerController : ControllerBase
    {
        [HttpPost("login")]
        public IActionResult LoginUser()
        {
            return Ok(new List<object>());
        }
    }
}
