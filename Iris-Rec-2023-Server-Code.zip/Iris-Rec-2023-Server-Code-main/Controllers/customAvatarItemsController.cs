﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class customAvatarItemsController : ControllerBase
    {
        [HttpGet("v1/isCreationAllowedForAccount")]
        public IActionResult idefk()
        {
            return Ok(new iscreationallowedforaccountresponse
            {
                success = true,
                value = null
            });
        }



        public class iscreationallowedforaccountresponse
        {
            [JsonPropertyName("success")] public bool success { get; set; }
            [JsonPropertyName("value")] public string value { get; set; }
        }
    }
}
