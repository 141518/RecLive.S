﻿using ir23.Data;
using ir23.VerificationModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class playersController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly JwtService _jwtService;

        public playersController(AppDbContext db, JwtService jwtService)
        {
            _db = db;
            _jwtService = jwtService;
        }



        [HttpGet("v2/progression/bulk")]
        public async Task<IActionResult> progressionbulk([FromQuery] List<int> id)
        {
            var finalprog = new List<progression>();

            foreach (int i in id)
            {


                var _progression = await _db.Progressions
                    .FirstOrDefaultAsync(x => x.PlayerId == i);

                if (_progression == null)
                {
                    _progression = new progression
                    {
                        PlayerId = i,
                        Level = 1,
                        XP = 0
                    };

                    _db.Progressions.Add(_progression);
                    await _db.SaveChangesAsync();


                }

                finalprog.Add(_progression);
            }

            return Ok(finalprog);
        }
    }
}
