﻿using ir23.Data;
using ir23.VerificationModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class playerReputationController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly JwtService _jwtService;

        public playerReputationController(AppDbContext db, JwtService jwtService)
        {
            _db = db;
            _jwtService = jwtService;
        }


        [HttpGet("v2/bulk")]
        public async Task<IActionResult> GetBulkRep([FromQuery] List<int> id)
        {
            var playerreputations = new List<reputation>();

            foreach (int i in id)
            {

                var rep = await _db.Reputations
                    .FirstOrDefaultAsync(x => x.accountId == i);

                if (rep == null)
                {
                    rep = new reputation
                    {
                        accountId = i,
                        IsCheerful = false,
                        Noteriety = 0,
                        CheerGeneral = 0,
                        CheerHelpful = 0,
                        CheerGreatHost = 0,
                        CheerSportsman = 0,
                        CheerCreative = 0,
                        CheerCredit = 20,
                        SubscriberCount = 0,
                        SubscribedCount = 0,
                        SelectedCheer = 0
                    };

                    _db.Reputations.Add(rep);
                    await _db.SaveChangesAsync();
                }

                playerreputations.Add(rep);

            }

            return Ok(playerreputations);
        }
    }
}
