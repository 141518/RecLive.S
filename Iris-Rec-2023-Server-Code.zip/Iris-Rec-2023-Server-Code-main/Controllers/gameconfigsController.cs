﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class gameconfigsController : ControllerBase
    {
        [HttpGet("v1/all")]
        public IActionResult allconfig()
        {
            return Ok(new List<object>());
        }
    }
}
