﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class versioncheckController : ControllerBase
    {
        [HttpGet("v4")]
        public IActionResult checkversion([FromQuery] string v)
        {
            if (v == "20230331")
            {
                return Ok(new
                {
                    VersionStatus = 0
                });
            }
            else
            {
                return Ok(new
                {
                    VersionStatus = 1
                });
            }
        }
    }
}
