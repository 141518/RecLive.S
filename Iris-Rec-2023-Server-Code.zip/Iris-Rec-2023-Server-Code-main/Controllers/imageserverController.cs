﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.AccessControl;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class imageserverController : ControllerBase
    {
        /*[HttpGet("{imagename}")]
        public async Task<IActionResult> GetImage([FromRoute] string imagename, [FromQuery] string? sig = null)
        {
            var path = Path.Combine(Directory.GetCurrentDirectory(), "cdn", "images", imagename);

            if (sig == "p1")
            {
                Response.Headers.Add("content-signature", "key-id=KEY:RSA:p1.rec.net; data=DE2ycF0i4LLjAnqUGvP6lqAPe3HGKLjmZ6nK8m3XidVFLabwQrYIb1WczC5Y6gN9MeDka0ux82yh29GrmSKEq85GSexTFlirnfoPGALl7fB5zeMfaQrwD0dbmO2vMnKe+ViP2RRCaotdYPYXWtEikpJUCVsH+o06EsBYOA3Nnxd93GQPnq0lo9Befjlxvhb9Q0gYBc45rPx0nkAYL2JixwDEroLgsQ8b69bnGE/gIAF0QkGwwDx2E4gMYJdL7xzWnpaIEsHjutFiot2cgHFYRIi0dJ4Ln7ExPgApQKa0Q4haU/qGvCBlhwtmbmnEFvlcX3bVlTcMGfcg6AKRKlRRpA==");
            }
            
            byte[] imagebytes = await System.IO.File.ReadAllBytesAsync(path);

            return File(imagebytes, "image/png");
        }*/
    }
}
