﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayerReportingController : ControllerBase
    {
        [HttpGet("v1/moderationBlockDetails")]
        public IActionResult modblockdetails()
        {
            return Ok(new
            {
                ReportCategory = 0,
                Duration = 0,
                GameSessionId = 0,
                Message = ""
            });
        }
    }
}
