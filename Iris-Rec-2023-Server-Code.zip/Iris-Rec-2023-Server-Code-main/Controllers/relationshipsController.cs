﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class relationshipsController : ControllerBase
    {
        [HttpGet("v2/get")]
        public IActionResult getRelationships()
        {
            return Ok(new List<object>());
        }
    }
}
