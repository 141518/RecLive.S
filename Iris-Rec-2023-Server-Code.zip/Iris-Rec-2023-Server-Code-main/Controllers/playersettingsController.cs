﻿using ir23.Data;
using ir23.VerificationModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class playersettingsController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly JwtService _jwtService;

        public playersettingsController(AppDbContext db, JwtService jwtService)
        {
            _db = db;
            _jwtService = jwtService;
        }



        [HttpGet]
        public async Task<IActionResult> GetSettings(
            [FromHeader] string Authorization
            )
        {

            var playerId = _jwtService.VerifyToken(Authorization);

            if (playerId == null) return Unauthorized();

            var playersettings = await _db.PlayerSettings
                .Where(x => x.accountId == playerId)
                .ToListAsync();

            return Ok(playersettings);
        }
    }
}
