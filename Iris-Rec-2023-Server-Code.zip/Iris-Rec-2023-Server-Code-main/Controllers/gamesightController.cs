﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class gamesightController : ControllerBase
    {
        [HttpPost("event")]
        public IActionResult evennetentio()
        {
            return Ok(new List<object>());
        }
    }
}
