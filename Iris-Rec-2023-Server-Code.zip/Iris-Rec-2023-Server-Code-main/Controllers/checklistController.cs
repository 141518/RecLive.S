﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class checklistController : ControllerBase
    {
        [HttpGet("v1/current")]
        public IActionResult ji0owefowjiefwefjoi()
        {
            return Ok(new List<object>());
        }
    }
}
