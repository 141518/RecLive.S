﻿using ir23.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class cachedloginController : ControllerBase
    {
        private readonly AppDbContext _db;

        public cachedloginController(AppDbContext db)
        {
            _db = db;
        }


        [HttpGet("forplatformid/{platform}/{platformid}")]
        public async Task<IActionResult> findcachedaccounts(
            [FromRoute] int platform,
            [FromRoute] string platformid
            )
        {

            var accountIds = await _db.PlatformDatas
                .Where(p => p.platform == platform && p.platformId == platformid)
                
                .ToListAsync();

            //.Select(p => p.accountId)


            /*var accounts = await _db.Accounts
                .Where(p => accountIds.Contains(p.Id))
                .ToListAsync();
            */

            return Ok(accountIds);
        }

        [HttpPost("forplatformids")]
        public async Task<IActionResult> efiojwo()
        {
            using (var reader = new StreamReader(Request.Body))
            {
                var body = await reader.ReadToEndAsync();
                Console.WriteLine(body);
            }

            return Ok(new List<object>());
        }
    }
}
