﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace ir23.Controllers
{
    [Route("/")]
    [ApiController]
    public class NameServerController : ControllerBase
    {

        public string serverUrl = "https://localhost:443";

        [HttpGet]
        public IActionResult NameServer()
        {
            return Ok(new
            {
                Accounts = serverUrl,
                AI = serverUrl,
                API = serverUrl,
                Auth = serverUrl,
                BugReporting = serverUrl,
                Cards = serverUrl,
                CDN = serverUrl+"/cdnserver",
                Chat = serverUrl,
                Clubs = serverUrl,
                CMS = serverUrl,
                Commerce = serverUrl,
                Data = serverUrl,
                DataCollection = serverUrl,
                Discovery = serverUrl,
                Econ = serverUrl,
                GameLogs = serverUrl,
                Geo = serverUrl,
                Images = serverUrl+"/imageserver",
                Leaderboard = serverUrl,
                Link = serverUrl,
                Lists = serverUrl,
                Matchmaking = serverUrl,
                Moderation = serverUrl,
                Notifications = serverUrl,
                PlatformNotifications = serverUrl,
                PlayerSettings = serverUrl,
                RoomComments = serverUrl,
                Rooms = serverUrl,
                Storage = serverUrl,
                Strings = serverUrl,
                StringsCDN = serverUrl+"/stringcdnserver",
                Studio = serverUrl,
                Thorn = serverUrl+"/thornserver",
                Videos = serverUrl+"/cdnserver",
                WWW = serverUrl

            });
        }
    }
}
