﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Net.Http;
using ir23.VerificationModels;
using Microsoft.AspNetCore.Http.Metadata;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class connectController : ControllerBase
    {

        private readonly SteamAuth _steamAuth;
        private readonly JwtService _jwtService;

        public connectController(SteamAuth steamAuth, JwtService jwtService)
        {
            _steamAuth = steamAuth;
            _jwtService = jwtService;
        }


        [HttpPost("token")]
        public async Task<IActionResult> connecttoken([FromForm] LoginRequest request)
        {
            if (request.grant_type == "refresh_token")
            {
                var refreshToken = Request.Form["refresh_token"].ToString();

                refreshToken = System.Text.RegularExpressions.Regex.Unescape(refreshToken);
                refreshToken = refreshToken.Trim();

                Console.WriteLine(refreshToken);

                var accountId = await _jwtService.ValidateRefreshToken(refreshToken);

                Console.WriteLine(accountId);

                if (accountId == null)
                    return Unauthorized();

                var accessToken = _jwtService.GenerateToken(accountId.Value);
                var newRefreshToken = await _jwtService.GenerateRefreshToken(accountId.Value);

                return Ok(new
                {
                    access_token = accessToken,
                    refresh_token = newRefreshToken,
                    error = "",
                    error_description = "",
                    key = ""
                });
            }

            var j = JsonSerializer.Deserialize<PlatformAuth>(request.platform_auth);

            if (j == null || string.IsNullOrEmpty(j.Ticket) || string.IsNullOrEmpty(j.AppId))
                return BadRequest();

            var steamResult = await _steamAuth.VerifySteamTicket(
                j.Ticket,
                j.AppId,
                request.account_id
            );

            if (steamResult)
            {
                var accessToken = _jwtService.GenerateToken(request.account_id);
                var refreshToken = await _jwtService.GenerateRefreshToken(request.account_id);

                return Ok(new
                {
                    access_token = accessToken,
                    refresh_token = refreshToken,
                    error = "",
                    error_description = "",
                    key = ""
                });
            }

            return Unauthorized();
        }











        public class LoginRequest
        {
            public string grant_type { get; set; }
            public long account_id { get; set; }
            public string client_id { get; set; }
            public string client_secret { get; set; }
            public string platform { get; set; }
            public string platform_id { get; set; }
            public string device_id { get; set; }
            public string device_class { get; set; }
            public string time { get; set; }
            public string ver { get; set; }
            public string cid { get; set; }
            public string build_key { get; set; }
            public string asid { get; set; }
            public string locale { get; set; }
            public string isInitialLogin { get; set; }
            public string dinfo { get; set; }
            public string eac_challenge { get; set; }
            public string eac_response { get; set; }
            public string platform_auth { get; set; }
        }

        public class PlatformAuth
        {
            public string Ticket { get; set; }
            public string AppId { get; set; }
        }
    }
}
