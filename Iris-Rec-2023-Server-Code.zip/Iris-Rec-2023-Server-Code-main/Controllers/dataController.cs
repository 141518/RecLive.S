﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class dataController : ControllerBase
    {
        [HttpPost("event")]
        public IActionResult eventttetetijeit()
        {
            return Ok(new List<object>());
        }
    }
}
