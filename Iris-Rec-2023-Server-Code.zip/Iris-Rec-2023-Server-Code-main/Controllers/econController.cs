﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class econController : ControllerBase
    {
        [HttpGet("customAvatarItems/v1/owned")]
        public IActionResult ownedavataritemscustom()
        {
            return Ok(new
            {
                Results = new List<object>(),
                TotalResults = 0
            });
        }
    }
}
