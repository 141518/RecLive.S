﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class threadController : ControllerBase
    {
        [HttpGet]
        public IActionResult getThreads()
        {
            return Ok(new List<object>());
        }
    }
}
