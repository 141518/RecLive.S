﻿using ir23.Data;
using ir23.VerificationModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class avatarController : ControllerBase
    {

        private readonly JwtService _jwtService;
        private readonly AppDbContext _db;

        public avatarController(JwtService jwtService, AppDbContext db)
        {
            _jwtService = jwtService;
            _db = db;
        }



        [HttpGet("v1/defaultunlocked")]
        public IActionResult defaultunlocked()
        {
            return Ok(new List<object>());
        }

        [HttpGet("v2")]
        public async Task<IActionResult> GetAvatar(
            [FromHeader] string Authorization
            )
        {
            var playerId = _jwtService.VerifyToken(Authorization);


            if (playerId == null) return Unauthorized();

            var avatardata = await _db.Avatars
                .FirstOrDefaultAsync(x => x.accountId == playerId);

            if (avatardata == null)
            {
                avatardata = new avatar
                {
                    accountId = playerId,
                    OutfitSelections = "",
                    FaceFeatures = "",
                    SkinColour = "",
                    HairColor = ""
                };

                _db.Avatars.Add(avatardata);
                await _db.SaveChangesAsync();
            }

            return Ok(avatardata);
        }

        [HttpGet("v4/items")]
        public IActionResult getMyUnlockedItems()
        {
            return Ok(new List<object>());
        }

        [HttpGet("v1/defaultbaseavataritems")]
        public IActionResult iofiowegjnioio()
        {
            return Ok(new List<object>());
        }
    }
}
