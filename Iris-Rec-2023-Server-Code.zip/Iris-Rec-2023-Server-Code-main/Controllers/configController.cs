﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class configController : ControllerBase
    {
        [HttpGet("v1/amplitude")]
        public IActionResult amplitudepls()
        {
            return Ok(new
            {
                AmplitudeKey = "6d44c7130493d0b7b217ca1281110d77",
                UseRudderStack = false,
                RudderStackKey = "",
                UseStatSig = true,
                StatSigKey = "client-55AOkoM7cfxsYT3yu5yoA01fo9Jipq9HQ1Y0IB6XHlj",
                StatSigEnvironment = 0
            });
        }
    }
}
