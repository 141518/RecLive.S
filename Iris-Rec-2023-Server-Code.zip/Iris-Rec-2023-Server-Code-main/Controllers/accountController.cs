﻿using ir23.Data;
using ir23.VerificationModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ir23.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class accountController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly JwtService _jwtService;

        public accountController(AppDbContext db, JwtService jwtService)
        {
            _db = db;
            _jwtService = jwtService;
        }


        [HttpGet("bulk")]
        public async Task<IActionResult> getbulkuserdata(
            [FromQuery] List<long> id
            )
        {
            var accountDatas = await _db.Accounts.Where(
                p => id.Contains(p.Id)
                ).ToListAsync();

            return Ok(accountDatas);
        }

        [HttpGet("me")]
        public async Task<IActionResult> getmyaccountdetails(
            [FromHeader] string Authorization
            )
        {

            var playerId = _jwtService.VerifyToken(Authorization);

            var account = await _db.Accounts
                .FirstOrDefaultAsync(p => p.Id == playerId);

            return Ok(account);
        }
    }
}
