﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ir23.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class objectivesController : ControllerBase
    {
        [HttpGet("v1/myprogress")]
        public IActionResult GetMyProgress()
        {
            return Ok(new
            {
                Objectives = new List<object>(),
                ObjectiveGroups = new List<object>()
            });
        }
    }
}
