using ir23.Data;
using ir23.Hubs;
using ir23.VerificationModels;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;
using System.Text.Json;

namespace ir23
{
    public class Program
    {

        

        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddHttpClient<SteamAuth>();
            builder.Services.AddScoped<JwtService>();

            builder.Services.AddSignalR();

            // Add services to the container.

            builder.Logging.AddFilter("Microsoft.EntityFrameworkCore.Database", LogLevel.None);

            builder.Services.AddControllers()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.PropertyNamingPolicy = null;
                });

            var connectionString = builder.Configuration.GetConnectionString("Default");

            builder.Services.AddDbContext<AppDbContext>(options => options.UseMySql(
                connectionString,
                new MySqlServerVersion(new Version(8,0,36)),
                mySqlOptions =>
                {
                    mySqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 5,
                        maxRetryDelay: TimeSpan.FromSeconds(5),
                        errorNumbersToAdd: null
                        );
                }
                ));

            var app = builder.Build();


            app.MapHub<SRHub>("/hub/v1");


            app.Use(async (context, next) =>
            {
                var start = DateTime.UtcNow;
                context.Request.EnableBuffering();
                var formData = context.Request.HasFormContentType ? (await context.Request.ReadFormAsync()).ToDictionary(f => f.Key, f => f.Value.ToString()) : new Dictionary<string, string>();
                var query = context.Request.Query.ToDictionary(q => q.Key, q => q.Value.ToString());
                await next();
                var duration = (DateTime.UtcNow - start).TotalMilliseconds;
                var request = context.Request;
                Console.WriteLine($"{context.Response.StatusCode} {request.Method} {request.Scheme}://{request.Host}{request.Path} {duration}ms\nQuery: {JsonSerializer.Serialize(query)}\nForm: {JsonSerializer.Serialize(formData)}");
            });

            // Configure the HTTP request pipeline.

            app.UseHttpsRedirection();

            app.UseAuthorization();



            app.MapControllers();

            app.Run();
        }
    }
}
