﻿using System.Text.Json.Serialization;
namespace ir23.VerificationModels
{
    public class steamparams
    {
        [JsonPropertyName("result")] public string result { get; set; }
        [JsonPropertyName("steamid")] public string steamid { get; set; }
        [JsonPropertyName("ownersteamid")] public string ownersteamid { get; set; }
        [JsonPropertyName("vacbanned")] public bool vacbanned { get; set; }
        [JsonPropertyName("publisherbanned")] public bool publisherbanned { get; set; }
    }

    public class steamresponse
    {
        [JsonPropertyName("params")]
        public steamparams @params { get; set; }
    }

    public class steamroot
    {
        [JsonPropertyName("response")]
        public steamresponse response { get; set; }
    }
}