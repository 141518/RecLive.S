﻿using ir23.Data;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;

namespace ir23.VerificationModels
{
    public class SteamAuth
    {
        private readonly HttpClient _httpClient;
        private readonly AppDbContext _db;


        public SteamAuth(HttpClient httpClient, AppDbContext db)
        {
            _httpClient = httpClient;
            _db = db;
        }



        public async Task<bool> VerifySteamTicket(string ticket, string appid, long accountid)
        {
            var url = "https://api.steampowered.com/ISteamUserAuth/AuthenticateUserTicket/v1" + $"?key=CHANGE MY KEY! TO VALID STEAM API KEY!&appid={appid}&ticket={ticket}";

            try
            {
                var response = await _httpClient.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();

                var j = JsonSerializer.Deserialize<steamroot>(content);

                var platformdata = await _db.PlatformDatas
                    .FirstOrDefaultAsync(p => p.accountId == accountid && p.platformId == j.response.@params.steamid);

                if (platformdata != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                return false;
            }

        }
    }

    

}
