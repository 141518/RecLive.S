﻿using ir23.Migrations;
using System.Text.Json.Serialization;

namespace ir23.Data
{
    public class reputation
    {
        [JsonPropertyName("Id")] public long Id { get; set; }
        [JsonPropertyName("accountId")] public required long accountId { get; set; }
        [JsonPropertyName("IsCheerful")] public required bool IsCheerful { get; set; }
        [JsonPropertyName("Noteriety")] public required int Noteriety { get; set; }
        [JsonPropertyName("CheerGeneral")] public required int CheerGeneral { get; set; }
        [JsonPropertyName("CheerHelpful")] public required int CheerHelpful { get; set; }
        [JsonPropertyName("CheerGreatHost")] public required int CheerGreatHost { get; set; }
        [JsonPropertyName("CheerSportsman")] public required int CheerSportsman { get; set; }
        [JsonPropertyName("CheerCreative")] public required int CheerCreative { get; set; }
        [JsonPropertyName("CheerCredit")] public required int CheerCredit { get; set; } = 20;
        [JsonPropertyName("SubscriberCount")] public required int SubscriberCount { get; set; } = 0;
        [JsonPropertyName("SubscribedCount")] public required int SubscribedCount { get; set; } = 0;
        [JsonPropertyName("SelectedCheer")] public required int SelectedCheer { get; set; } = 0;
    }
}
