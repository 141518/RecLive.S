﻿using System.Text.Json.Serialization;

namespace ir23.Data
{
    public class refreshtable
    {
        public long Id { get; set; }
        public required string RefreshToken { get; set; }
        public required DateTime ExpiryTime { get; set; } = DateTime.UtcNow + TimeSpan.FromDays(7);
        public required long AccountId { get; set; }
    }
}
