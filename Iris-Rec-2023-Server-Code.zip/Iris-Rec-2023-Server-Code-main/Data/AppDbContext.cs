﻿using Microsoft.EntityFrameworkCore;

namespace ir23.Data
{
    public class AppDbContext : DbContext
    {

        public DbSet<PlatformData> PlatformDatas { get; set; }
        public DbSet<account> Accounts { get; set; }
        public DbSet<refreshtable> refreshtables { get; set; }
        public DbSet<avatar> Avatars { get; set; }
        public DbSet<playersetting> PlayerSettings { get; set; }
        public DbSet<reputation> Reputations { get; set; }
        public DbSet<progression> Progressions { get; set; }
        

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {

        }
    }
}
