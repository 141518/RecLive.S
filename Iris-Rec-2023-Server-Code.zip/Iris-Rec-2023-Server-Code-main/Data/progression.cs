﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace ir23.Data
{
    public class progression
    {
        [JsonPropertyName("Id")] public long Id { get; set; }
        [JsonPropertyName("PlayerId")] public long PlayerId { get; set; }
        [JsonPropertyName("Level")] public int Level { get; set; }
        [JsonPropertyName("XP")] public int XP { get; set; }
    }
}
