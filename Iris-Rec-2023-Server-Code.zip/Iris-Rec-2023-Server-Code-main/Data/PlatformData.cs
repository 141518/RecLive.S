﻿using System.Text.Json.Serialization;

namespace ir23.Data
{
    public class PlatformData
    {
        [JsonPropertyName("Id")] public long Id { get; set; }
        [JsonPropertyName("platform")] public int platform { get; set; }
        [JsonPropertyName("platformId")] public string platformId { get; set; }
        [JsonPropertyName("accountId")] public long accountId { get; set; }
        [JsonPropertyName("lastLoginTime")] public DateTime lastLoginTime { get; set; } = DateTime.UtcNow;
    }
}
