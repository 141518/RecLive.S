﻿using ir23.Migrations;
using System.Text.Json.Serialization;

namespace ir23.Data
{
    public class playersetting
    {
        [JsonPropertyName("Id")] public long Id { get; set; }
        [JsonPropertyName("accountId")] public required long accountId { get; set; }
        [JsonPropertyName("Key")] public required string Key { get; set; }
        [JsonPropertyName("Value")] public required string Value { get; set; }
    }
}
