﻿using System.Text.Json.Serialization;

namespace ir23.Data
{
    public class account
    {

        [JsonPropertyName("accountId")] public long Id { get; set; }
        [JsonPropertyName("displayName")] public required string displayName { get; set; }
        [JsonPropertyName("bannerImage")] public required string bannerImage { get; set; } = "defaultpfp.png";
        [JsonPropertyName("createdAt")] public required DateTime createdAt { get; set; } = DateTime.UtcNow;
        [JsonPropertyName("isJunior")] public required bool isJunior { get; set; } = false;
        [JsonPropertyName("platforms")] public int platforms { get; set; } = 0;
        [JsonPropertyName("profileImage")] public required string profileImage { get; set; } = "defaultpfp.png";
        [JsonPropertyName("username")] public required string username { get; set; }
        [JsonPropertyName("developer")] public bool developer { get; set; } = false;
    }
}
