﻿using System.Text.Json.Serialization;

namespace ir23.Data
{
    public class avatar
    {
        [JsonPropertyName("Id")] public long Id { get; set; }
        [JsonPropertyName("accountId")] public long accountId { get; set; }
        [JsonPropertyName("OutfitSelections")] public required string OutfitSelections { get; set; } = "";
        [JsonPropertyName("FaceFeatures")] public required string FaceFeatures { get; set; } = "";
        [JsonPropertyName("SkinColor")] public required string SkinColour { get; set; } = "";
        [JsonPropertyName("HairColor")] public required string HairColor { get; set; } = "";
    }
}
