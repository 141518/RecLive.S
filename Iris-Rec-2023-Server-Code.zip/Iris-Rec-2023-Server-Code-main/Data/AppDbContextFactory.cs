﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace ir23.Data
{
    public class AppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
    {
        public AppDbContext CreateDbContext(string[] args)
        {
            var connectionString = "server=us5.abrhosting.com;port=3306;database=s341_adminpanel;user=u341_JbImfFUYNs;password=tm8mEnRyDi8i1HS^3@hzt4FZ;";

            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();

            optionsBuilder.UseMySql(connectionString,
                new MySqlServerVersion(new Version(8, 0, 36))
                );

            return new AppDbContext(optionsBuilder.Options);
        }
    }
}
