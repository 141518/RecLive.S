# chat we need to fix logging in time it takes forever to load into dorm when logging in bruv
